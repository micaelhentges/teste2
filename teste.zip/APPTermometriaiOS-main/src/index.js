import 'react-native-gesture-handler';
import React from 'react';
import {StatusBar} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import Routes from './routes';
//import CodePush from 'react-native-code-push';

const App = () => {
  return (
    <NavigationContainer>
      <>
        <StatusBar barStyle="light-content" backgroundColor="#ff7500" />
        <Routes />
      </>
    </NavigationContainer>
  );
};

/*export default CodePush({
  checkFrequency: CodePush.CheckFrequency.ON_APP_RESUME,
})(App);
*/

//Implementação Igor
export default App;