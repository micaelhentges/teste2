import React from 'react';
import {View, StyleSheet, Text, ScrollView} from 'react-native';

import Sensor from '../Sensor';

export default props => {
  let temps = props.temps;
  temps = temps.sort((a, b) => a[0] - b[0]);

  let nsens = temps[0] && temps[0][1];
  if (nsens) {
    temps.map(item => {
      // console.log(item[0] + '::' + item[1]);
      if (Number(nsens) < Number(item[1])) {
        nsens = item[1];
      }
    });
  }

  let nsens2 = Number(nsens) + 1;
  let tabela = [];
  let cabos = [];

  //Coluna com o numero do sensor
  cabos.push(
    <Text style={styles.isensor} key={0}>
      {' '}
    </Text>
  );
  for (let j = nsens; j > 0; j--) {
    cabos.push(
      <Text style={styles.isensor} key={j}>
        S{j}
      </Text>
    );
  }
  let cb = <View key={-1}>{cabos}</View>;
  tabela.push(cb);

  //Percorre todos os cabos
  for (let i = 0; i < temps.length; i++) {
    // Nr do cabo
    let cabos = [];
    cabos.push(
      <Text style={[styles.sensor, {fontWeight: 'bold'}]} key={0}>
        P{temps[i][0].trim()}
      </Text>
    );
    for (let j = nsens2; j > 1; j--) {
      if (j < temps[i].length) {
        let t = parseFloat(temps[i][j].trim());
        if (t > 0) {
          t = t.toFixed(1);
          cabos.push(<Sensor key={j} valor={t} />);
        }
      } else {
        cabos.push(<Sensor key={j} valor={null} />);
      }
    }
    let cb = <View key={i}>{cabos}</View>;
    tabela.push(cb);
  }

  return (
    <View style={styles.containerLista}>
      <View style={{flex: 1}}>
        <ScrollView horizontal={true}>{tabela}</ScrollView>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  containerLista: {
    flex: 1,
    width: '100%',
    alignItems: 'center',
    alignContent: 'center',
    padding: 10,
  },
  sensor: {
    fontSize: 14,
    textAlign: 'center',
    marginLeft: 1,
    marginRight: 1,
    borderWidth: 0,
    backgroundColor: '#DDD',
  },
  isensor: {
    fontSize: 14,
    textAlign: 'left',
    marginLeft: 1,
    marginRight: 1,
    borderWidth: 0,
    paddingLeft: 2,
    backgroundColor: '#DDD',
    color: '#AAA',
  },
});
