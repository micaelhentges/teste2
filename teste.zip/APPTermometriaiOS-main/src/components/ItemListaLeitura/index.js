import React from 'react';
import {View, StyleSheet, Text, TouchableOpacity} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import Swipeable from 'react-native-swipeable';

export default props => {
  const rightContent = [
    <TouchableOpacity
      style={styles.exclude}
      onPress={() => props.onDelete(props.IdLeitura)}>
      <Svg
        viewBox="0 0 448 512"
        style={{color: '#F00', size: 15, height: 15, width: 15}}>
        <Path
          fill="#000"
          d="M440 64H336l-33.6-44.8A48 48 0 0 0 264 0h-80a48 48 0 0 0-38.4 19.2L112 64H8a8 8 0 0 0-8 8v16a8 8 0 0 0 8 8h18.9l33.2 372.3a48 48 0 0 0 47.8 43.7h232.2a48 48 0 0 0 47.8-43.7L421.1 96H440a8 8 0 0 0 8-8V72a8 8 0 0 0-8-8zM171.2 38.4A16.1 16.1 0 0 1 184 32h80a16.1 16.1 0 0 1 12.8 6.4L296 64H152zm184.8 427a15.91 15.91 0 0 1-15.9 14.6H107.9A15.91 15.91 0 0 1 92 465.4L59 96h330z"
        />
      </Svg>
    </TouchableOpacity>,
  ];

  return (
    <Swipeable rightButtons={rightContent}>
      <View style={styles.containerLista}>
        {props.loggedin ? (
          <View style={styles.touchContainer}>
            <TouchableOpacity style={styles.itemContainer} onPress={() =>
                props.onClick(
                  props.IdSilo,
                  props.Data,
                  props.equipamento,
                  props.IdLeitura
                )
              }>
              <Text style={styles.silo}>{props.nomeExib}</Text>
              <Text style={styles.data}>{props.Data}</Text>
              <View style={styles.uploadIcon}>
              <Svg
                style={{color: '#F00', size: 15, height: 15, width: 15, marginLeft:'auto',marginRight:'auto'}}
                viewBox="0 0 512 512">
                <Path
                  fill="currentColor"
                  d="M452 432c0 11-9 20-20 20s-20-9-20-20 9-20 20-20 20 9 20 20zm-84-20c-11 0-20 9-20 20s9 20 20 20 20-9 20-20-9-20-20-20zm144-48v104c0 24.3-19.7 44-44 44H44c-24.3 0-44-19.7-44-44V364c0-24.3 19.7-44 44-44h124v-99.3h-52.7c-35.6 0-53.4-43.1-28.3-68.3L227.7 11.7c15.6-15.6 40.9-15.6 56.6 0L425 152.4c25.2 25.2 7.3 68.3-28.3 68.3H344V320h124c24.3 0 44 19.7 44 44zM200 188.7V376c0 4.4 3.6 8 8 8h96c4.4 0 8-3.6 8-8V188.7h84.7c7.1 0 10.7-8.6 5.7-13.7L261.7 34.3c-3.1-3.1-8.2-3.1-11.3 0L109.7 175c-5 5-1.5 13.7 5.7 13.7H200zM480 364c0-6.6-5.4-12-12-12H344v24c0 22.1-17.9 40-40 40h-96c-22.1 0-40-17.9-40-40v-24H44c-6.6 0-12 5.4-12 12v104c0 6.6 5.4 12 12 12h424c6.6 0 12-5.4 12-12V364z"
                  class=""
                />
              </Svg>
              </View>
            </TouchableOpacity>
          </View>
        ) : (
          <TouchableOpacity
            style={styles.touchContainer}
            onPress={() =>
              props.onClick(
                props.IdLeitura,
                props.Data,
                props.nomeExib,
                props.pendulos
              )
            }>
            <View style={styles.itemContainer}>
              <Text style={styles.silo}>{`${props.nomeExib} : ${
                props.IdLeitura ? props.IdLeitura : props.idTermometria
              }`}</Text>
              <Text style={styles.data}>{props.Data}</Text>
            </View>
          </TouchableOpacity>
        )}
      </View>
    </Swipeable>
  );
};

const styles = StyleSheet.create({
  containerLista: {
    flex: 1,
    padding: 10,
    marginTop: 3,
    marginLeft: 5,
    marginRight: 5,
    backgroundColor: '#EEE',
    borderRadius: 5,
  },
  touchContainer: {
    flexDirection: 'row',
    width: '100%',
  },
  itemContainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  data: {
    paddingLeft: 10,
    fontSize: 12,
    color: 'grey',
    fontWeight: 'bold',
  },
  uploadIcon: {
    width: 30
  },
  silo: {
    paddingLeft: 10,
    fontSize: 12,
    color: 'grey',
    fontWeight: 'bold',
  },
  exclude: {
    flex: 1,
    backgroundColor: '#CCC',
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 3,
    borderRadius: 5,
    justifyContent: 'flex-start',
    paddingLeft: 20,
  },
});
