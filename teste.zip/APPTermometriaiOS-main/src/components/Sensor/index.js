import React from 'react';
import {StyleSheet, Text} from 'react-native';

export default props => {
  let corTemp = {color: '#000'};

  if (props.valor > 0 && props.valor <= 10) {
    corTemp = {color: '#E0ECF8'};
  } else if (props.valor > 10 && props.valor <= 20) {
    corTemp = {color: '#00F'};
  } else if (props.valor > 20 && props.valor <= 25) {
    corTemp = {color: '#0F0'};
  } else if (props.valor > 25 && props.valor <= 30) {
    corTemp = {color: '#D7DF01'};
  } else if (props.valor > 30 && props.valor <= 40) {
    corTemp = {color: 'F00'};
  } else if (props.valor > 40 && props.valor <= 100) {
    corTemp = {color: '#A901DB'};
  } else {
    corTemp = {color: '#000'};
  }

  return <Text style={[styles.sensor, corTemp]}>{props.valor}</Text>;
};

const styles = StyleSheet.create({
  sensor: {
    fontSize: 14,
    textAlign: 'center',
    marginLeft: 1,
    marginRight: 1,
    borderWidth: 0,
    backgroundColor: '#EEE',
    fontWeight: 'bold',
  },
});
