import React from 'react';
import {StyleSheet, Text, View, ActivityIndicator} from 'react-native';

export default function Loading(props) {
  const {text} = props;

  return (
    <View style={styles.container}>
      <ActivityIndicator color="#fff" size="large" />
      <Text style={styles.text}>{text && text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
    fontWeight: '700',
    height: '100%',
    justifyContent: 'center',
    position: 'absolute',
    textAlign: 'center',
    width: '100%',
    zIndex: 9999,
  },
  text: {
    color: '#fff',
    marginTop: 5,
  },
  svg: {
    width: 60,
    height: 60,
  },
});
