import React from 'react';
import {View, StyleSheet, Text, TouchableOpacity} from 'react-native';
import Svg, {Path} from 'react-native-svg';
// import Icon from 'react-native-vector-icons/FontAwesome'

export default props => {
  return (
    <View style={styles.containerSC}>
      <View style={styles.statusContainer}>
        <Svg viewBox="0 0 448 512" style={{color: '#555'}}>
          <Path
            fill="currentColor"
            d="M224 32c106 0 192 28.75 192 64v32c0 35.25-86 64-192 64S32 163.25 32 128V96c0-35.25 86-64 192-64m192 149.5V224c0 35.25-86 64-192 64S32 259.25 32 224v-42.5c41.25 29 116.75 42.5 192 42.5s150.749-13.5 192-42.5m0 96V320c0 35.25-86 64-192 64S32 355.25 32 320v-42.5c41.25 29 116.75 42.5 192 42.5s150.749-13.5 192-42.5m0 96V416c0 35.25-86 64-192 64S32 451.25 32 416v-42.5c41.25 29 116.75 42.5 192 42.5s150.749-13.5 192-42.5M224 0C145.858 0 0 18.801 0 96v320c0 77.338 146.096 96 224 96 78.142 0 224-18.801 224-96V96c0-77.338-146.096-96-224-96z"
          />
        </Svg>
      </View>
      <View style={styles.touchDeviceContainer}>
        <View style={styles.deviceContainer}>
          <Text style={styles.deviceName}>{props.nomeExib}</Text>
        </View>
      </View>

      <TouchableOpacity
        style={styles.touchDeleteContainer}
        onPress={() => props.onEditaSilo(props.IdSilo)}>
        <View style={styles.deleteContainer}>
          {/* <Icon name='edit' size={20} color='#555' /> */}
          <Svg viewBox="0 0 576 512">
            <Path
              fill="currentColor"
              d="M417.8 315.5l20-20c3.8-3.8 10.2-1.1 10.2 4.2V464c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V112c0-26.5 21.5-48 48-48h292.3c5.3 0 8 6.5 4.2 10.2l-20 20c-1.1 1.1-2.7 1.8-4.2 1.8H48c-8.8 0-16 7.2-16 16v352c0 8.8 7.2 16 16 16h352c8.8 0 16-7.2 16-16V319.7c0-1.6.6-3.1 1.8-4.2zm145.9-191.2L251.2 436.8l-99.9 11.1c-13.4 1.5-24.7-9.8-23.2-23.2l11.1-99.9L451.7 12.3c16.4-16.4 43-16.4 59.4 0l52.6 52.6c16.4 16.4 16.4 43 0 59.4zm-93.6 48.4L403.4 106 169.8 339.5l-8.3 75.1 75.1-8.3 233.5-233.6zm71-85.2l-52.6-52.6c-3.8-3.8-10.2-4-14.1 0L426 83.3l66.7 66.7 48.4-48.4c3.9-3.8 3.9-10.2 0-14.1z"
            />
          </Svg>
        </View>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.touchDeleteContainer}
        onPress={() => props.onDeleteSilo(props.IdSilo)}>
        <View style={styles.deleteContainer}>
          {/* <Icon name='trash' size={20} color='#555' /> */}
          <Svg viewBox="0 0 448 512" style={{color: '#F00'}}>
            <Path
              fill="currentColor"
              d="M440 64H336l-33.6-44.8A48 48 0 0 0 264 0h-80a48 48 0 0 0-38.4 19.2L112 64H8a8 8 0 0 0-8 8v16a8 8 0 0 0 8 8h18.9l33.2 372.3a48 48 0 0 0 47.8 43.7h232.2a48 48 0 0 0 47.8-43.7L421.1 96H440a8 8 0 0 0 8-8V72a8 8 0 0 0-8-8zM171.2 38.4A16.1 16.1 0 0 1 184 32h80a16.1 16.1 0 0 1 12.8 6.4L296 64H152zm184.8 427a15.91 15.91 0 0 1-15.9 14.6H107.9A15.91 15.91 0 0 1 92 465.4L59 96h330z"
            />
          </Svg>
        </View>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  containerSC: {
    flexDirection: 'row',
    padding: 10,
    paddingTop: 15,
    paddingBottom: 15,
    marginTop: 10,
    backgroundColor: '#DDD',
    borderRadius: 10,
    height: 50,
  },

  //Indica estado do Dispositivo - On Off
  statusContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '10%',
  },
  //Indica estado do Dispositivo - On Off

  deviceName: {
    paddingLeft: 10,
    fontSize: 17,
    color: 'grey',
    fontWeight: 'bold',
  },
  touchDeleteContainer: {
    width: '15%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  deleteContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },

  touchDeviceContainer: {
    width: '60%',
  },
  deviceContainer: {
    justifyContent: 'center',
  },
});
