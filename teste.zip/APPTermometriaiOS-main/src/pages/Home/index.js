import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ImageBackground,
  ScrollView,
  Image,
  AsyncStorage,
} from 'react-native';
import Tooltip from 'react-native-walkthrough-tooltip';
import {openDatabase} from 'react-native-sqlite-storage';

import fundo from '../../../assets/silo.jpg';
import logo from '../../../assets/logo.png';
import logoSync from '../../../assets/logoSyncB.png';

export default function Main(props) {
  const [toolTipHome, setToolTipHome] = useState(false);
  const db = openDatabase({name: 'baseDados.db'});

  useEffect(() => {
    _toolTipOpen();
    //Verifica se as tabelas existem no banco de dados, caso não existe serão criadas
    db.transaction(function(txn) {
      txn.executeSql(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='Leituras'",
        [],
        function(tx, res) {
          console.log('Leituras: ', res.rows.length);
          if (res.rows.length == 0) {
            txn.executeSql('DROP TABLE IF EXISTS Leituras', []);
            txn.executeSql(
              'CREATE TABLE IF NOT EXISTS Leituras( IdLeitura INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, Data TEXT NOT NULL, IdSilo INTEGER )',
              [],
            );
          }
        },
      );
      txn.executeSql(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='Silos'",
        [],
        function(tx, res) {
          console.log('Silos: ', res.rows.length);
          if (res.rows.length == 0) {
            txn.executeSql('DROP TABLE IF EXISTS Silos', []);
            txn.executeSql(
              'CREATE TABLE IF NOT EXISTS Silos( IdSilo INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, nomeDevice TEXT NOT NULL, macDevice TEXT NOT NULL, nomeExib TEXT NOT NULL, ordemExib INTEGER NOT NULL, equipamento INTEGER )',
              [],
            );
          }
        },
      );
      txn.executeSql(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='Temperaturas'",
        [],
        function(tx, res) {
          console.log('Temperaturas: ', res.rows.length);
          if (res.rows.length == 0) {
            txn.executeSql('DROP TABLE IF EXISTS Temperaturas', []);
            txn.executeSql(
              'CREATE TABLE IF NOT EXISTS Temperaturas( IdTemperatura INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, IdLeitura INTEGER NOT NULL, NumCabo INTEGER NOT NULL, Temperaturas TEXT NOT NULL )',
              [],
            );
          }
        },
      );
      txn.executeSql(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='DadosEmpresa'",
        [],
        function(tx, res) {
          console.log('DadosEmpresa: ', res.rows.length);
          if (res.rows.length == 0) {
            txn.executeSql('DROP TABLE IF EXISTS DadosEmpresa', []);
            txn.executeSql(
              'CREATE TABLE IF NOT EXISTS DadosEmpresa( IdEmpresa INTEGER NOT NULL PRIMARY KEY, Nome TEXT NOT NULL, EnderecoEmpresa TEXT NOT NULL, TelefoneEmpresa TEXT NOT NULL )',
              [],
            );
            txn.executeSql(
              'INSERT INTO DadosEmpresa(Nome, IdEmpresa, EnderecoEmpresa, TelefoneEmpresa) VALUES (?,?,?,?)',
              [' ', 1, ' ', ' '],
            );
          }
        },
      );
      txn.executeSql(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='paramEmail'",
        [],
        function(tx, res) {
          console.log('paramEmail: ', res.rows.length);
          if (res.rows.length == 0) {
            txn.executeSql('DROP TABLE IF EXISTS paramEmail', []);
            txn.executeSql(
              'CREATE TABLE IF NOT EXISTS paramEmail( idParams INTEGER NOT NULL PRIMARY KEY, destinatario TEXT NOT NULL )',
              [],
            );
            txn.executeSql(
              'INSERT INTO paramEmail(idParams, destinatario) VALUES (?,?)',
              [1, ''],
            );
          }
        },
      );
    });
  }, []); // eslint-disable-line

  async function _toolTipOpen() {
    const value = await AsyncStorage.getItem('toolTipHome');

    setToolTipHome(toolTipHome ? false : true);
  }

  async function _toolTipClose() {
    setToolTipHome(false);
    await AsyncStorage.setItem('toolTipHome', 'false');
  }

  return (
    <ImageBackground source={fundo} style={styles.background}>
      <ScrollView>
        <View style={styles.container}>
          <Image style={styles.imgLogo} source={logo} resizeMode="contain" />
          <Text style={styles.welcome}>Termometria Digital</Text>
          <Text style={styles.welcome2}>Portátil</Text>
          <TouchableOpacity
            style={styles.botoes}
            onPress={() => props.navigation.navigate('FazerLeitura')}>
            <Text style={styles.textoBotoes}>Fazer Leitura</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.botoes}
            onPress={() => props.navigation.navigate('ConsultarLeituras')}>
            <Text style={styles.textoBotoes}>Consultar Leituras</Text>
          </TouchableOpacity>
          
          <Tooltip
            animated={true}
            //(Optional) When true, tooltip will animate in/out when showing/hiding
            arrowSize={{width: 16, height: 8}}
            //(Optional) Dimensions of arrow bubble pointing to the highlighted element
            backgroundColor="rgba(0,0,0,0.5)"
            //(Optional) Color of the fullscreen background beneath the tooltip.
            isVisible={toolTipHome}
            //(Must) When true, tooltip is displayed
            content={<Text>Clique aqui para configurar seu Aplicativo</Text>}
            //(Must) This is the view displayed in the tooltip
            placement="bottom"
            //(Must) top, bottom, left, right, auto.
            onClose={() => _toolTipClose()}
            //(Optional) Callback fired when the user taps the tooltip
          >
            <TouchableOpacity
              style={styles.botoes}
              onPress={() => {
                props.navigation.navigate('Silos'), _toolTipClose();
              }}>
              <Text style={styles.textoBotoes}>Configurar Silos</Text>
            </TouchableOpacity>
          </Tooltip>

          <View style={styles.rodape}>
            <Image
              style={styles.imgLogoSync}
              source={logoSync}
              resizeMode="contain"
            />
          </View>
        </View>
        <Text style={styles.version}>Versão 1.7</Text>
      </ScrollView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  container: {
    flex: 1,
    alignItems: 'center',
  },
  imgLogo: {
    height: 30,
    marginTop: 30,
    marginBottom: 20,
  },
  imgLogoSync: {
    height: 35,
    margin: 5,
  },
  welcome: {
    fontSize: 22,
    color: '#FFF',
    textAlign: 'center',
    margin: 1,
    paddingTop: 0,
  },
  welcome2: {
    fontSize: 24,
    color: '#FFF',
    textAlign: 'center',
    margin: 1,
    paddingTop: 5,
    paddingBottom: 5,
    fontWeight: 'bold',
  },
  botoes: {
    width: 250,
    backgroundColor: '#666',
    opacity: 0.9,
    borderRadius: 7,
    alignItems: 'center',
    margin: 10,
    padding: 15,
  },
  textoBotoes: {
    color: '#FE9A2E',
    fontSize: 16,
  },
  rodape: {
    flex: 1,
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
  },
  textoRodape: {
    fontSize: 10,
    color: '#FFF',
    paddingBottom: 5,
    opacity: 0.4,
  },
  version: {
    fontSize: 12,
    color: '#fff',
    textAlign: 'center',
    fontWeight: '700',
  },
});

/* BOTÃO ENVIAR PARA A NUVEM
<TouchableOpacity
  style={styles.botoes}
  onPress={() => props.navigation.navigate('EnviarNuvem')}>
  <Text style={styles.textoBotoes}>Enviar para Nuvem</Text>
</TouchableOpacity>
*/