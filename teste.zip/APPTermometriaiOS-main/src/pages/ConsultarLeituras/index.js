import React, {Component} from 'react';
import {StyleSheet, Text, View, ScrollView, FlatList} from 'react-native';

//Banco de dados
import {openDatabase} from 'react-native-sqlite-storage';

import ItemListaLeitura from '../../components/ItemListaLeitura';

export default class ConsultarLeituras extends Component {
  constructor(props) {
    super(props);

    this.state = {
      leituras: [],
    };

    this.db = openDatabase({name: 'baseDados.db'});
    this.getDadosBD();
  }

  getDadosBD = () => {
    this.db.transaction(tx => {
      tx.executeSql(
        'SELECT l.IdLeitura, l.Data, l.IdSilo, s.nomeExib FROM Leituras l INNER JOIN Silos s on s.macDevice = l.IdSilo or s.IdSilo = l.IdSilo ORDER BY l.IdLeitura DESC',
        [],
        (tx, results) => {
          //console.log('ConsultaLeituras - seleciona')
          //console.log(results.rows)

          var temp = [];
          for (let i = 0; i < results.rows.length; ++i) {
            temp.push(results.rows.item(i));
          }
          //this.setState({ leituras: temp.map(silo => ({ ...silo, online: false })) })
          this.setState({leituras: temp});
          //console.log('ConsultaLeituras - Leituras do state')
          //console.log(this.state.leituras)
        }
      );
    });
  };

  abreLeitura = (id, data, nomeExib) => {
    //console.log('abre leitura ' + id)
    this.props.navigation.navigate('VisualizarLeitura', {
      idLeitura: id,
      data: data,
      nomeExib: nomeExib,
    });
  };

  deletaLeitura = id => {
    //console.log('deleta ' + id)
    this.db.transaction(tx => {
      tx.executeSql(
        'DELETE from Leituras where IdLeitura = ?',
        [id],
        (tx, results) => {
          console.log('ConsultaLeituras - Deleta');
          console.log(results.rows);
          this.getDadosBD();
        }
      );
    });
  };

  render() {
    return (
      <View style={styles.container}>
        <ScrollView style={styles.scrollLeituras}>
          <FlatList
            data={this.state.leituras}
            keyExtractor={item => `${item.IdLeitura}`}
            renderItem={({item}) => (
              <ItemListaLeitura
                {...item}
                onClick={this.abreLeitura}
                onDelete={this.deletaLeitura}
              />
            )}
          />
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollLeituras: {
    flex: 1,
    width: '100%',
  },
});
