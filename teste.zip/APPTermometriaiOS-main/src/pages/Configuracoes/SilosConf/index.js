import React, {Component} from 'react';
import {
  View,
  Text,
  TextInput,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';

//Banco de dados
import {openDatabase} from 'react-native-sqlite-storage';

let atualiza = false;

export default class SilosConf extends Component {
  constructor(props) {
    super(props);
    //console.log('SilosConf - constructor')
    this.dvc = this.props.route.params.device ? this.props.route.params.device : null;
    this.idSilo = this.props.route.params.idSilo
      ? this.props.route.params.idSilo
      : 0;

    console.log(props.route.params.dvc);

    this.state = {
      nomeDevice: '',
      macDevice: '',
      nomeExib: '',
      ordemExib: '',
    };

    this.db = openDatabase({name: 'baseDados.db'});
  }

  componentWillMount() {
    console.log('SilosConf - componentWillMount');
    // Verificar se recebeu ID, Com ID pega o objeto que vem do banco de TabSilos, Sem ID pega o objeto que vem do bluetooth de TabSilosAdd
    // Ai fazer o setState de acordo com o que veio

    if (this.idSilo !== 0) {
      // Está atualizando - Localizar no banco
      console.log('IdSilo: ' + this.idSilo);
      this.db.transaction(tx => {
        tx.executeSql(
          'SELECT * FROM Silos where IdSilo = ?',
          [this.idSilo],
          (tx, results) => {
            console.log('registro localizado no banco');
            console.log(results.rows.item(0));
            const temp = results.rows.item(0);
            const nomeDevice = results.rows.item(0).nomeDevice;
            const macDevice = results.rows.item(0).macDevice;
            const nomeExib = results.rows.item(0).nomeExib;
            const ordemExib = results.rows.item(0).ordemExib;
            console.log('setar estado');

            this.setState({
              idSilo: this.idSilo,
              nomeDevice: nomeDevice,
              macDevice: macDevice,
              nomeExib: nomeExib,
              ordemExib: ordemExib,
            });

            console.log(this.state);
            console.log('estado setado');
          }
        );
      });
    } else {
      this.setState({
        idSilo: this.idSilo,
        nomeDevice: this.dvc.item.name ? this.dvc.item.name : this.dvc.item.id,
        macDevice: this.dvc.item.id,
        nomeExib: '',
        ordemExib: '',
      });
    }
  }

  SalvaSilo = () => {
    console.log('SalvaSilo');
    console.log(this.state);
    var that = this;
    const nomeDevice = this.state.nomeDevice.trim();
    const macDevice = this.state.macDevice.trim();
    const nomeExib = this.state.nomeExib.trim();
    const ordemExib = this.state.ordemExib.toString().trim();
    const navigation = this.props.navigation;
    if (nomeDevice) {
      if (macDevice) {
        if (nomeExib) {
          if (ordemExib) {
            console.log(this.state);
            if (this.idSilo != 0) {
              //UPDATE
              console.log('Update');
              this.db.transaction(tx => {
                console.log('transaction');
                tx.executeSql(
                  'UPDATE Silos set nomeDevice=?, macDevice=? , nomeExib=? , ordemExib=? where IdSilo=?',
                  [
                    nomeDevice,
                    macDevice,
                    nomeExib,
                    ordemExib,
                    this.idSilo,
                  ],
                  (txn, results) => {
                    console.log('Results ', results);
                    if (results.rowsAffected > 0) {
                      atualiza = true;
                      Alert.alert('Sucesso', 'Dados gravados corretamente', [
                        {
                          text: 'OK',
                          onPress: () => navigation.navigate('Silos'),
                        },
                      ]);
                    } else {
                      Alert.alert('Erro', 'Falha ao gravar dados');
                    }
                  }
                );
              });
            } else {
              // INSERT
              console.log('Insert');
              this.db.transaction(tx => {
                console.log('transaction');
                tx.executeSql(
                  'INSERT INTO Silos (nomeDevice, macDevice, nomeExib, ordemExib) VALUES (?, ?, ?, ?)',
                  [nomeDevice, macDevice, nomeExib, ordemExib],
                  (txn, results) => {
                    console.log('Results ', results);
                    if (results.rowsAffected > 0) {
                      atualiza = true;
                      Alert.alert('Sucesso', 'Dados gravados corretamente', [
                        {
                          text: 'OK',
                          onPress: () => navigation.navigate('Silos'),
                        },
                      ]);
                    } else {
                      Alert.alert('Erro', 'Falha ao gravar dados');
                    }
                  }
                );
              });
            }
          } else {
            Alert.alert('Erro', 'Ordem Exibição!');
          }
        } else {
          Alert.alert('Erro', 'Nome de Exibição!');
        }
      } else {
        Alert.alert('Erro', 'Mac Address!');
      }
    } else {
      Alert.alert('Erro', 'Nome do Dispositivo!');
    }
  };

  render() {
    return (
      <View style={styles.container}>
        <ScrollView style={styles.scroll}>
          <View style={styles.items}>
            <Text style={styles.label}>Nome do Dispositivo:</Text>
            <TextInput
              style={styles.input}
              value={this.state.nomeDevice ? this.state.nomeDevice : ''}
              editable={false}
            />
          </View>

          <View style={styles.items}>
            <Text style={styles.label}>Mac Address:</Text>
            <TextInput
              style={styles.input}
              value={this.state.macDevice ? this.state.macDevice : ''}
              editable={false}
              onChangeText={macDevice => this.setState({macDevice})}
            />
          </View>

          <View style={styles.items}>
            <Text style={styles.label}>Nome de Exibição:</Text>
            <TextInput
              style={styles.input}
              value={this.state.nomeExib ? this.state.nomeExib : ''}
              onChangeText={nomeExib => this.setState({nomeExib})}
            />
          </View>

          <View style={styles.items}>
            <Text style={styles.label}>Ordem Exibição:</Text>
            <TextInput
              style={styles.input}
              value={
                this.state.ordemExib ? this.state.ordemExib.toString() : ''
              }
              onChangeText={ordemExib => this.setState({ordemExib})}
            />
          </View>

          <TouchableOpacity
            style={styles.button}
            onPress={this.SalvaSilo.bind(this)}>
            <Text style={styles.buttonLabel}>Salvar</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height: '100%',
    backgroundColor: '#FFF',
  },

  scroll: {
    flex: 1,
    height: '100%',
    width: '100%',
    padding: 15,
    backgroundColor: '#FFF',
  },

  items: {
    width: '100%',
    alignItems: 'flex-start',
    paddingBottom: 10,
  },
  label: {
    paddingBottom: 5,
  },
  input: {
    height: 40,
    width: '100%',
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: '#e3e3e3',
    borderRadius: 6,
  },

  button: {
    width: '100%',
    backgroundColor: '#777',
    borderRadius: 7,
    alignItems: 'center',
    marginTop: 25,
    padding: 15,
  },
  buttonLabel: {
    color: '#FE9A2E',
    fontSize: 16,
  },
});
