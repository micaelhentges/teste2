import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
} from 'react-native';

//Banco de dados
import {openDatabase} from 'react-native-sqlite-storage';

import SiloCadastrado from '../../../components/SiloCadastrado';

export default function Silos(props) {
  const [silos, setSilos] = useState([]);
  const db = openDatabase({name: 'baseDados.db'});

  function getDadosBD() {
    db.transaction(tx => {
      tx.executeSql(
        'SELECT * FROM Silos order by ordemExib',
        [],
        (tx, results) => {
          //console.log('Tabsilos - seleciona')
          //console.log(results)
          var temp = [];
          for (let i = 0; i < results.rows.length; ++i) {
            temp.push(results.rows.item(i));
            // Ou aqui, ou fazer um looping depois, para verificar os que estão online -- Acho que vai ter que ser depois
            // Por hora abortada a ideia
          }
          //console.log('Tabsilos - set state')
          setSilos(temp.map(silo => ({...silo, online: false})));
          //console.log('Tabsilos - silos')
          //console.log(silos)
        },
      );
    });
  }

  function onAtualizaTela() {
    getDadosBD();
  }

  function excluirSilo(silo) {
    db.transaction(tx => {
      tx.executeSql(
        'DELETE FROM Silos where IdSilo = ?',
        [silo],
        (tx, results) => {
          if (results.rowsAffected > 0) {
            Alert.alert(
              'Termometria Portátil',
              'Silo Excluído!',
              [
                {
                  text: 'Ok',
                  onPress: () => console.log('OK'),
                },
              ],
              {cancelable: false},
            );
            onAtualizaTela();
          } else {
            alert('Erro ao excluír Silo!');
          }
        },
      );
    });
  }

  function onDeleteSilo(silo) {
    Alert.alert(
      'Termo Portátil',
      'Deseja realmente excluir este Silo?',
      [
        {
          text: 'Cancelar',
          onPress: () => console.log('Tabsilos - Cancel Pressed'),
          style: 'cancel',
        },
        {text: 'OK', onPress: () => excluirSilo(silo)},
      ],
      {cancelable: false},
    );
  }

  function onEditaSilo(silo) {
    props.navigation.navigate('SilosConf', {
      idSilo: silo,
      onAtualizaTela: atualiza => (atualiza ? onAtualizaTela() : false),
    });
  }

  useEffect(() => {
    getDadosBD();
  }, [getDadosBD]);

  return (
    <>
      <FlatList
        style={styles.container}
        data={silos}
        keyExtractor={item => `${item.IdSilo}`}
        renderItem={({item}) => (
          <SiloCadastrado
            {...item}
            onEditaSilo={onEditaSilo}
            onDeleteSilo={onDeleteSilo}
          />
        )}
      />
      <TouchableOpacity
        onPress={() => {
          props.navigation.navigate('SilosAdd');
        }}
        style={styles.button}>
        <Text style={styles.buttonText}>+</Text>
      </TouchableOpacity>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height: 100,
  },
  button: {
    position: 'absolute',
    right: 15,
    bottom: 30,
    width: 50,
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 50,
    backgroundColor: '#FE9A2E',
    color: '#fff',
    padding: 0,
  },
  buttonText: {
    color: '#fff',
    fontSize: 35,
    padding: 0,
    marginBottom: 4,
  },
});
