import React, {useState, useEffect} from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  AsyncStorage,
} from 'react-native';

import Tooltip from 'react-native-walkthrough-tooltip';

export default function Configuracoes(props) {
  const [toolTipEmpresa, setToolTipEmpresa] = useState(false);
  const [toolTipSilo, setToolTipSilo] = useState(false);

  async function _toolTipOpen() {
    const value = await AsyncStorage.getItem('toolTipHome');
    if (value !== null) {
      // We have data!!
      //alert(value)
      if (value == 'false') {
        //this.setState({toolTipHome:false})
        const value2 = await AsyncStorage.getItem('toolTipEmpresa');
        if (value2 !== null) {
          // We have data!!
          //alert(value)
          if (value2 == 'false') {
            setToolTipEmpresa(false);
            const value3 = await AsyncStorage.getItem('toolTipSilo');
            if (value3 !== null) {
              // We have data!!
              //alert(value)
            } else {
              setToolTipSilo(true);
            }
          }
        } else {
          setToolTipEmpresa(true);
        }
      }
    }
  }

  async function _toolTipClose() {
    if (toolTipEmpresa) {
      setToolTipEmpresa(false);
      await AsyncStorage.setItem('toolTipEmpresa', 'false');
    }

    if (toolTipSilo) {
      setToolTipSilo(false);
      await AsyncStorage.setItem('toolTipSilo', 'false');
    }
  }

  useEffect(() => {
    props.navigation.addListener('didFocus', payload => {
      console.debug('didFocus', payload);
      _toolTipOpen();
    });
  }, []); //eslint-disable-line

  return (
    <ScrollView style={styles.scrool}>
      <View style={styles.container}>
        <View style={styles.containerBotoes}>
          <Tooltip
            animated={true}
            arrowSize={{width: 16, height: 8}}
            backgroundColor="rgba(0,0,0,0.5)"
            isVisible={toolTipEmpresa}
            content={<Text>Cadastre sua empresa</Text>}
            placement="bottom"
            onClose={() => _toolTipClose()}>
            {/* <TouchableOpacity
              style={styles.botoes}
              onPress={() => {
                props.navigation.navigate('TabEmpresa'), _toolTipClose();
              }}>
              <Text style={styles.textoBotoes}>Empresa</Text>
            </TouchableOpacity> */}
          </Tooltip>

          <Tooltip
            animated={true}
            arrowSize={{width: 16, height: 8}}
            backgroundColor="rgba(0,0,0,0.5)"
            isVisible={toolTipSilo}
            content={<Text>Cadastre o primeiro Silo</Text>}
            placement="bottom"
            onClose={() => _toolTipClose()}>
            <TouchableOpacity
              style={styles.botoes}
              onPress={() => {
                props.navigation.navigate('Silos'), _toolTipClose();
              }}>
              <Text style={styles.textoBotoes}>Silos</Text>
            </TouchableOpacity>
          </Tooltip>

          <TouchableOpacity
            style={styles.botoes}
            onPress={() => props.navigation.navigate('Email')}>
            <Text style={styles.textoBotoes}>E-Mail</Text>
          </TouchableOpacity>
          <Text style={styles.textoVersao}>Versão: 2.0</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scrool: {
    backgroundColor: '#DDD',
  },
  container: {
    flex: 1,
  },

  containerBotoes: {
    flex: 1,
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 20,
    height: '100%',
  },
  botoes: {
    width: 250,
    backgroundColor: '#666',
    opacity: 0.9,
    borderRadius: 7,
    alignItems: 'center',
    margin: 10,
    padding: 15,
  },
  textoBotoes: {
    color: '#FE9A2E',
    fontSize: 16,
  },

  textoVersao: {
    paddingTop: 10,
    color: '#555',
    fontSize: 12,
  },
});
