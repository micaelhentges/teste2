import React, {Component} from 'react';
import {
  Alert,
  AsyncStorage,
  FlatList,
  NativeEventEmitter,
  NativeModules,
  PermissionsAndroid,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  ToastAndroid,
  TouchableOpacity,
  View,
} from 'react-native';

import BleManager, {getDiscoveredPeripherals} from 'react-native-ble-manager';

const BleManagerModule = NativeModules.BleManager;
const bleManagerEmitter = new NativeEventEmitter(BleManagerModule);

import Tooltip from 'react-native-walkthrough-tooltip';

import {openDatabase} from 'react-native-sqlite-storage';

export default class SilosAdd extends Component {
  constructor(props) {
    super(props);
    this.state = {
      scaning: false,
      isConnected: false,
      text: '',
      writeData: '',
      receiveData: '',
      readData: '',
      data: [],
      isMonitoring: false,
      isEnabled: false,
      scanning: false,
      processing: false,
      silos: [],
      devices: [],
      serial: false,
      toolTipBT: false,

      peripherals: new Map(),
      appState: '',
    };
    this.db = openDatabase({name: 'baseDados.db'});
    this.bluetoothReceiveData = []; //Cache de dados recebidos por Bluetooth
    this.deviceMap = new Map();

    this.handleDiscoverPeripheral = this.handleDiscoverPeripheral.bind(this);
    this.handleStopScan = this.handleStopScan.bind(this);
    this.handleUpdateValueForCharacteristic = this.handleUpdateValueForCharacteristic.bind(
      this
    );
    this.handleDisconnectedPeripheral = this.handleDisconnectedPeripheral.bind(
      this
    );
    //this.handleAppStateChange = this.handleAppStateChange.bind(this);
  }

  getDadosBD = () => {
    //console.log('TabSilosAdd - getDadosBD')
    this.db.transaction(tx => {
      tx.executeSql('SELECT * FROM Silos ', [], (tx, results) => {
        console.log('Tabsilos - seleciona');
        console.log(results);
        var temp = [];
        for (let i = 0; i < results.rows.length; ++i) {
          //temp.push( results.rows.item(i) )
          // Ou aqui, ou fazer um looping depois, para verificar os que estão online -- Acho que vai ter que ser depois
          // Por hora abortada a ideia
          for (let j = 0; j < this.silosDevice.length; j++) {
            if (this.silosDevice[j].id === results.rows.item(i).macDevice) {
              this.silosDevice[j].cadastrado = true;
            } else {
              //temp.push(this.silosDevice[j])
            }
          }
        }

        this.setState({
          isEnabled: this.btAtivo,
          devices: this.silosDevice
            .map(device => ({...device}))
            .filter(device => device.cadastrado == false),
        });
      });
    });
  };

  retrieveConnected() {
    BleManager.getConnectedPeripherals([]).then(results => {
      // if (results.length == 0) {
      //   console.log('No connected peripherals');
      // }
      console.log(results);
      var peripherals = this.state.peripherals;
      for (var i = 0; i < results.length; i++) {
        var peripheral = results[i];
        peripheral.connected = true;
        peripherals.set(peripheral.id, peripheral);
        this.setState({peripherals});
      }
    });
  }

  handleDiscoverPeripheral(peripheral) {
    var peripherals = this.state.peripherals;
    if (!peripheral.name) {
      peripheral.name = 'NO NAME';
    }
    peripherals.set(peripheral.id, peripheral);
    this.setState({peripherals});
  }

  handleDisconnectedPeripheral(data) {
    let peripherals = this.state.peripherals;
    let peripheral = peripherals.get(data.peripheral);
    if (peripheral) {
      peripheral.connected = false;
      peripherals.set(peripheral.id, peripheral);
      this.setState({peripherals});
    }
    console.log('Disconnected from ' + data.peripheral);
  }

  handleUpdateValueForCharacteristic(data) {
    console.log(
      'Received data from ' +
        data.peripheral +
        ' characteristic ' +
        data.characteristic,
      data.value
    );
  }

  handleStopScan() {
    console.log('Scan is stopped');
    this.setState({scanning: false});
  }

  startScan() {
    if (!this.state.scanning) {
      if (Platform.OS === 'android' && Platform.Version >= 23) {
        PermissionsAndroid.check(
          PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
        ).then(result => {
          if (result) {
            console.log('Permission is OK');
          } else {
            //PermissionsAndroid.requestPermission(
            PermissionsAndroid.request(
              PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
            ).then(result => {
              if (result) {
                console.log('User accept');
              } else {
                console.log('User refuse');
              }
            });
          }
        });
      }
      //this.setState({peripherals: new Map()});
      BleManager.scan([], 30, true).then(results => {
        console.log('Scanning...');
        this.setState({scanning: true});
      });
    }
  }

  componentDidMount() {
    BleManager.start({showAlert: false});

    this.handlerDiscover = bleManagerEmitter.addListener(
      'BleManagerDiscoverPeripheral',
      this.handleDiscoverPeripheral
    );
    this.handlerStop = bleManagerEmitter.addListener(
      'BleManagerStopScan',
      this.handleStopScan
    );
    this.handlerDisconnect = bleManagerEmitter.addListener(
      'BleManagerDisconnectPeripheral',
      this.handleDisconnectedPeripheral
    );
    this.handlerUpdate = bleManagerEmitter.addListener(
      'BleManagerDidUpdateValueForCharacteristic',
      this.handleUpdateValueForCharacteristic
    );

    if (Platform.OS === 'android' && Platform.Version >= 23) {
      PermissionsAndroid.check(
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION,
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
        //PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE,
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
      ).then(result => {
        if (result) {
          console.log('Permission is OK');
        } else {
          //PermissionsAndroid.requestPermission(
          PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
            PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION,
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
            //PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE,
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT,
          ).then(result => {
            if (result) {
              console.log('User accept');
            } else {
              console.log('User refuse');
            }
          });
        }
      });
    }
  }

  async scan() {
    console.log('startscan');
    console.log(this.state.scanning);
    /*if (!this.state.scanning) {
      BleManager.scan([], 3, true).then(results => {
        console.log('Scanning scan...');
        this.setState({scanning: true});
      });
    }*/
    BleManager.scan([], 5, true).then(() => {
      // Success code
      console.log("Scan started");
      this.setState({scanning: true});
    });
  }

  componentWillUnmount() {
    this.handlerDiscover.remove();
    this.handlerStop.remove();
    this.handlerDisconnect.remove();
    this.handlerUpdate.remove();
  }

  componentWillMount() {
    this.props.navigation.addListener('didFocus', payload => {
      console.debug('didFocus', payload);
      this._toolTipOpen();
    });
  }

  async _toolTipOpen() {
    const value = await AsyncStorage.getItem('toolTipSilo');
    if (value !== null) {
      if (value == 'false') {
        const value2 = await AsyncStorage.getItem('toolTipBT');
        if (value2 !== null) {
          // We have data!!
          //alert(value)
        } else {
          this.setState({toolTipBT: true});
        }
      }
    }

    //const value = await AsyncStorage.getItem('toolTipEmpresa');
    //this.setState({toolTipHome:value ? false:true})
  }

  async _toolTipClouse() {
    if (this.state.toolTipBT) {
      this.setState({toolTipBT: false});
      await AsyncStorage.setItem('toolTipBT', 'false');
    }
  }

  alert(text) {
    Alert.alert('Prompt', text, [{text: 'Determinar', onPress: () => {}}]);
  }

  renderItem = item => {
    let data = item.item;
    return (
      <TouchableOpacity
        activeOpacity={0.7}
        disabled={this.state.isConnected ? true : false}
        onPress={() => {
          this.btnConfig(item);
        }}
        style={styles.item}>
        <View style={{flexDirection: 'row'}}>
          <Text style={{color: 'black'}}>{data.name ? data.name : ''}</Text>
          <Text style={{color: 'red', marginLeft: 50}}>
            {data.isConnecting ? 'Em conexão...' : ''}
          </Text>
        </View>
        <Text>{data.id}</Text>
      </TouchableOpacity>
    );
  };

  renderHeader = () => {
    return (
      <View style={{padding: 15}}>
        <Tooltip
          animated={true}
          arrowSize={{width: 16, height: 8}}
          backgroundColor="rgba(0,0,0,0.5)"
          isVisible={this.state.toolTipBT}
          content={
            <Text>
              Verifique se o Bluetooth está ligado e caso você possui uma das
              primeiras versões da termometria portátil provavelmente vai usar o
              Bluetooth Clássico, sendo que o para usar o Bluetooth Clássico é
              necessário parear o dispositivo.
            </Text>
          }
          placement="bottom"
          onClose={() => this._toolTipClouse()}
        >
          <View style={{flex: 1, flexDirection: 'row', alignItems: 'center'}}>
            <TouchableOpacity
              activeOpacity={0.7}
              style={[
                styles.buttonView,
                {
                  marginRight: 10,
                  height: 40,
                  textAlign: 'center',
                  width: '100%',
                },
              ]}
              onPress={
                this.state.isConnected
                  ? this.disconnect.bind(this)
                  : this.startScan.bind(this)
              }>
              <Text style={styles.buttonText}>
                {this.state.scaning
                  ? 'Pesquisando'
                  : this.state.isConnected
                  ? 'Desconectar o Bluetooth'
                  : 'Pesquisa por Bluetooth'}
              </Text>
            </TouchableOpacity>
          </View>
        </Tooltip>

        <Text style={{marginTop: 10, textAlign: 'center', fontWeight: '700'}}>
          {this.state.peripherals > 0 && 'Equipamentos disponíveis'}
        </Text>
      </View>
    );
  };

  render() {
    const list = Array.from(this.state.peripherals.values());
    return (
      <View style={styles.container}>
        <View style={styles.devices}>
          <FlatList
            renderItem={this.renderItem}
            keyExtractor={item => item.id}
            data={list}
            ListHeaderComponent={this.renderHeader}
            extraData={[
              this.state.isConnected,
              this.state.text,
              this.state.receiveData,
              this.state.readData,
              this.state.writeData,
              this.state.isMonitoring,
              this.state.scaning,
            ]}
            keyboardShouldPersistTaps="handled"
          />
        </View>
      </View>
    );
  }

  btnConfig = item => {
    this.props.navigation.navigate('SilosConf', {
      device: item,
      onAtualizaTela: atualiza => this.onAtualizaTela(atualiza),
    });
  };

  onAtualizaTela = atualiza => {
    //this.disconnect()
    //console.log('TabsilosAdd - Atualiza Tela')
    //console.log(atualiza)
    this.getDadosBD();
    //Se atualiza for true, esconder o que foi adicionado
  };
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height: '100%',
    backgroundColor: '#FFF',
  },
  cabecalho2: {
    backgroundColor: '#EEE',
    alignItems: 'center',
    width: '100%',
    paddingTop: 3,
  },
  subTitulo: {
    fontSize: 14,
    padding: 5,
    textAlign: 'center',
    color: '#FACC2E',
  },

  devices: {
    flex: 1,
    width: '100%',
  },
  deviceNameWrap: {
    flexDirection: 'row',
    padding: 10,
    marginTop: 10,
    marginLeft: 10,
    marginRight: 10,
    backgroundColor: '#DDD',
    borderRadius: 10,
  },
  deviceName: {
    paddingLeft: 10,
    fontSize: 15,
    color: 'grey',
  },
  item: {
    flexDirection: 'column',
    borderColor: 'rgb(235,235,235)',
    borderStyle: 'solid',
    borderBottomWidth: StyleSheet.hairlineWidth,
    paddingLeft: 10,
    paddingVertical: 8,
  },
  buttonView: {
    height: 30,
    backgroundColor: 'rgb(33, 150, 243)',
    paddingHorizontal: 10,
    borderRadius: 5,
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
    fontSize: 12,
  },
});
