import React, {Component} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Alert,
  TouchableOpacity,
  PermissionsAndroid,
} from 'react-native';

import Mailer from 'react-native-mail';
import RNHTMLtoPDF from 'react-native-html-to-pdf';
import Share from 'react-native-share';

//Banco de dados
import {openDatabase} from 'react-native-sqlite-storage';
var db = openDatabase({name: 'baseDados.db'});

import TabelaSilo from '../../components/TabelaSilo';

let idLeitura = 0;
let data = '';
let nomeExib = '';
let nomeEmpresa = '';
let enderecoEmpresa = '';
let pendulos = '';

export default class VisualizarLeitura extends Component {
  constructor(props) {
    super(props);

    this.arquivo = '';

    async function requestExternalWritePermission() {
      if (Platform.OS === 'android' && Platform.Version >= 23) {
        try {
          const granted = await PermissionsAndroid.request(
            PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
            {
              title: 'CameraExample App External Storage Write Permission',
              message:
                'CameraExample App needs access to Storage data in your SD Card ',
            }
          );
          if (granted === PermissionsAndroid.RESULTS.GRANTED) {

          } else {
            alert('WRITE_EXTERNAL_STORAGE permission denied');
          }
        } catch (err) {
          alert('Write permission err', err);
          console.warn(err);
        }
      }
    }
    //Calling the External Write permission function
    requestExternalWritePermission();

    console.log(this.props.route.params.idLeitura)
    idLeitura = this.props.route.params.idLeitura ? this.props.route.params.idLeitura : 0;
    data = this.props.route.params.data ? this.props.route.params.data : '';
    nomeExib = this.props.route.params.nomeExib ? this.props.route.params.nomeExib : '';
    pendulos = this.props.route.params.pendulos ? this.props.route.params.pendulos : [];

    this.state = {
      temperaturas: [],
    };
    this.getDadosBD();
  }

  getDadosBD = () => {
    console.log('getDadosBD()');
    if (!idLeitura) {
      var temp = [];
      for (aux in pendulos) {
        temp.push(pendulos[aux].Temperaturas);
      }
      this.state.temperaturas = temp;
    } else {
      db.transaction(tx => {
        tx.executeSql(
          'SELECT * FROM Temperaturas WHERE IdLeitura = ?',
          [idLeitura],
          (tx, results) => {
            var temp = [];
            for (let i = 0; i < results.rows.length; ++i) {
              temp.push(results.rows.item(i).Temperaturas.split(','));
            }
            this.setState({temperaturas: temp});
          }
        );
        tx.executeSql(
          'SELECT * FROM DadosEmpresa WHERE IdEmpresa = ?',
          [1],
          (tx, results) => {
            nomeEmpresa = results.rows.item(0).Nome;
            enderecoEmpresa = results.rows.item(0).EnderecoEmpresa;
          }
        );
      });
    }
  };

  onVoltar = () => {
    console.log('onVoltar()');
    this.props.navigation.goBack(null);
  };

  async pdf() {
    console.log('pdf()');
    let html =
      '<html><body><center><br /><b><p>' +
      nomeEmpresa +
      '</p></b><p>' +
      enderecoEmpresa +
      '</p>';
    html =
      html +
      '<br /><p>Relat&oacute;rio de Termometria</p><p>' +
      data +
      '</p><p>' +
      nomeExib +
      '</p>';
    html =
      html + '<table style="border: 1px solid #EEE"><thead> <tr> <th></th>';
    for (let i = 0; i < this.state.temperaturas.length; i++) {
      html =
        html +
        '<th style="border: 1px solid #EEE">P' +
        this.state.temperaturas[i][0] +
        '</th>';
    }
    html = html + '</tr> </thead> <tbody>';

    let corTemp = '#FFF';
    console.log(this.state.temperaturas);

    //Percorre todos os níveis de sensores
    for (let j = 16; j > 1; j--) {
      html =
        html +
        '<tr><th align=\'left\' style="border: 1px solid #EEE">S' +
        (j - 1) +
        '</th>';
      //Percorre todos os cabos
      for (let i = 0; i < this.state.temperaturas.length; i++) {
        if (j - 1 <= this.state.temperaturas[i][1]) {
          console.log(this.state.temperaturas[i][j]);
          let temp = this.state.temperaturas[i][j];
          if (temp > 0 && temp <= 10) {
            corTemp = '#E0ECF8';
          } else if (temp > 10 && temp <= 20) {
            corTemp = '#58ACFA';
          } else if (temp > 20 && temp <= 25) {
            corTemp = '#81F781';
          } else if (temp > 25 && temp <= 30) {
            corTemp = '#F4FA58';
          } else if (temp > 30 && temp <= 40) {
            corTemp = '#F00';
          } else if (temp > 40 && temp <= 100) {
            corTemp = '#A901DB';
          } else {
            corTemp = '#FFF';
          }
          html =
            html +
            '<td style="border: 1px solid #EEE; background-color: ' +
            corTemp +
            ';">' +
            temp +
            '</td>';
        } else {
          console.log('cabo: ' + (i + 1) + ' sensor: ' + (j - 1) + ' vaziu');
          html =
            html +
            '<td style="border: 1px solid #EEE">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>';
        }
      }
      html = html + '</tr>';
    }
    html = html + '</center></tbody></table></body></html>';

    let options = {
      //Content to print
      html: html,
      //File Name
      fileName: 'relatorio ' + data,
      //File directory
      directory: 'docs',
    };
    let file = await RNHTMLtoPDF.convert(options);
    this.arquivo = file.filePath;
  }

  shareMessage = async () => {
    const result = await Share.open({
      title: "This is my report ",
      message: "Relatório de termometria em anexo " + nomeExib + " - " + data,
      //url: "file:///storage/emulated/0/Android/data/com.apptermometria/files/docs/relatorio.pdf",
      url: this.arquivo,
      subject: "Relatório Termometria " + data + " - " + nomeExib,
    });
  };

  async toShare() {
    console.log('toShare()');
    await this.pdf();
    await this.shareMessage();
  }

  render() {
    return (
      <View style={styles.container}>
        <View style={styles.titulo}>
          <Text style={styles.textoTitulo}>{nomeExib}</Text>
          <Text style={styles.textoTitulo}>{data}</Text>
        </View>

        <TabelaSilo temps={this.state.temperaturas} onVoltar={this.onVoltar} />

        <View style={styles.linhaBotoes}>
          <TouchableOpacity
            style={styles.button}
            onPress={() => this.onVoltar()}>
            <Text style={styles.buttonLabel}>Fechar</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => this.toShare()}>
            <Text style={styles.buttonLabel}>Compartilhar</Text>
          </TouchableOpacity>

        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  //Silo Selecionado ou Selecione Silo
  titulo: {
    backgroundColor: '#EEE',
    alignItems: 'center',
    width: '100%',
  },
  textoTitulo: {
    fontSize: 14,
    padding: 2,
  },
  //Silo Selecionado ou Selecione Silo FIM

  linhaBotoes: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#EEE',
    paddingLeft: 15,
    paddingRight: 15,
  },
  button: {
    backgroundColor: '#666',
    width: 105,
    height: 40,
    margin: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
  },
  buttonLabel: {
    fontSize: 16,
    color: '#FE9A2E',
    //fontWeight: 'bold',
  },
});
