import React, {Component} from 'react';
import Loading from '../../components/Loading';
import Auth from './Auth';
import LoggedIn from './LoggedIn';
import deviceStorage from '../../services/deviceStorage.js';

export default class EnviarNuvem extends Component {
  constructor(props) {
    super(props);
    this.state = {
      jwt: '',
      loading: true,
      id_usuario: 0,
      id_unidade: 0,
      id_empresa: 0,
      nivelAcesso: 5,
    };

    this.newJWT = this.newJWT.bind(this);
    this.deleteJWT = deviceStorage.deleteJWT.bind(this);
    this.loadJWT = deviceStorage.loadJWT.bind(this);
    this.loadJWT();
  }

  newJWT(data) {
    this.setState({
      jwt: data.token,
      id_usuario: data.usuario.id,
      id_unidade: data.usuario.idUnidade,
      id_empresa: data.usuario.idEmpresa,
      nivelAcesso: data.usuario.nivelAcesso,
    });
  }

  render() {
    if (this.state.loading) {
      return <Loading />;
    } else if (!this.state.jwt) {
      return <Auth navigation={this.props.navigation} newJWT={this.newJWT} />;
    } else if (this.state.jwt) {
      return (
        <LoggedIn
          navigation={this.props.navigation}
          user={this.state}
          deleteJWT={this.deleteJWT}
        />
      );
    }
  }
}
