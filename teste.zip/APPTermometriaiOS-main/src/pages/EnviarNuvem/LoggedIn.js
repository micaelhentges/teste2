import React, {Component} from 'react';
import {
  View,
  Text,
  ScrollView,
  FlatList,
  TouchableOpacity,
  Modal,
  Alert,
  Picker,
} from 'react-native';
import Loading from '../../components/Loading';
import axios from 'axios';

//Banco de dados
import {openDatabase} from 'react-native-sqlite-storage';
var db = openDatabase({name: 'baseDados.db'});

import ItemListaLeitura from '../../components/ItemListaLeitura';

export default class LoggedIn extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      cloud: [],
      leituras: [],
      leiturasCloud: [],
      error: '',
      tabLeitura: false,
      uploadMessage: '',
      equipamento: 0,
      cloudEquipamentos: [],
      selectIdSilo: 0,
      modalVisible: false,
      pendulos: [],
      dataHora: '',
      idSiloUP: 0,
    };
  }

  getDadosBD = () => {
    db.transaction(tx => {
      tx.executeSql(
        'SELECT * FROM Leituras l INNER JOIN Silos s on s.macDevice = l.IdSilo or s.IdSilo = l.IdSilo ORDER BY l.IdLeitura DESC',
        [],
        (tx, results) => {
          //console.log('ConsultaLeituras - seleciona')
          //console.log(results.rows)

          var temp = [];
          for (let i = 0; i < results.rows.length; ++i) {
            temp.push(results.rows.item(i));
          }
          //this.setState({ leituras: temp.map(silo => ({ ...silo, online: false })) })
          this.setState({leituras: temp});
          //console.log('ConsultaLeituras - Leituras do state')
          //console.log(this.state.leituras)
        }
      );
    });
  };

  abreLeitura = (id, data, nomeExib, pendulos) => {
    //console.log('abre leitura ' + id)
    this.props.navigation.navigate('VisualizarLeitura', {
      idLeitura: id,
      data: data,
      nomeExib: nomeExib,
      pendulos: pendulos,
    });
  };

  deletaLeitura = id => {
    db.transaction(tx => {
      tx.executeSql(
        'DELETE from Leituras where IdLeitura = ?',
        [id],
        (tx, results) => {
          this.getDadosBD();
        }
      );
    });
  };

  componentDidMount() {
    this.getDadosBD();
    // Set config defaults when creating the instance
    const instance = axios.create({
      baseURL: 'https://iot.kepler.com.br/api',
    });

    // Alter defaults after instance has been created
    instance.defaults.headers.common['Authorization'] =
      'Bearer ' + this.props.user.jwt;

    instance
      .get(
        '/termometria?id_empresa=' +
          this.props.user.id_empresa +
          '&id_unidade=' +
          this.props.user.id_unidade
      )
      .then(response => {
        let {data} = response.data;
        data.map(item => {
          let newItem = item;
          newItem.Data = item.dataHora;
          return newItem;
        });

        data.reverse();

        this.setState({
          cloud: data,
          loading: false,
        });
      })
      .catch(erro => {
        this.setState({
          error: erro + '',
          loading: false,
        });
      });
  }

  getEquipamento() {
    // Set config defaults when creating the instance
    const instance = axios.create({
      baseURL: 'https://iot.kepler.com.br/api',
    });

    // Alter defaults after instance has been created
    instance.defaults.headers.common['Authorization'] =
      'Bearer ' + this.props.user.jwt;

    instance
      .get(
        '/equipamentos?id_empresa=' +
          this.props.user.id_empresa +
          '&id_unidade=' +
          this.props.user.id_unidade
      )
      .then(response => {
        let {data} = response.data;
        this.setState({
          cloudEquipamentos: data,
          equipamento: 0,
        });
      })
      .catch(erro => {
        this.setState({
          error: erro + '',
          loading: false,
        });
      });
  }

  upload = async (idSilo, dataHora, equipamento) => {
    this.setState({loading: true});
    if (equipamento == null) {
      await this.getEquipamento();
      this.setState({modalVisible: true});
      this.setState({selectIdSilo: idSilo});
    } else {
      const instance = axios.create({
        baseURL: 'https://iot.kepler.com.br/api',
      });
      // Alter defaults after instance has been created
      instance.defaults.headers.common['Authorization'] =
        'Bearer ' + this.props.user.jwt;

      await instance
        .post('/termometria', {
          data: {
            idEquipamento: equipamento,
            dataHora: dataHora,
            dataNivel: dataHora,
            layoutSilo: '9022',
          },
          pendulos: this.state.pendulos,
        })
        .then(response => {
          Alert.alert('Envio', 'Leitura salva com sucesso!');
          this.setState({
            uploadMessage: response + '',
            equipamento: 0,
          });
        })
        .catch(erro => {
          console.log(erro);
        });
    }
    this.setState({loading: false});
  };

  updateSilo(itemValue) {
    if (itemValue != '0') {
      this.setState({equipamento: itemValue});
      db.transaction(tx => {
        tx.executeSql(
          'UPDATE Silos set equipamento=? where IdSilo=?',
          [itemValue, this.state.selectIdSilo],
          (tx, results) => {
            console.log('Results', results.rowsAffected);
            if (results.rowsAffected > 0) {
              Alert.alert('Sucesso', 'Equipamento selecionado', [
                {
                  text: 'OK',
                  onPress: () => {
                    this.getDadosBD(),
                      this.setState({modalVisible: !this.state.modalVisible});
                  },
                },
              ]);
            } else {
              Alert.alert('Erro', 'Falha ao selecionar equipamento');
            }
          }
        );
      });
    }
  }

  getTemperaturas = async (idSilo, dataHora, equipamento, auxid = 1) => {
    try {
      await db.transaction(tx => {
        tx.executeSql(
          'SELECT * FROM Temperaturas WHERE IdLeitura = ?',
          [auxid],
          (tx, results) => {
            //console.log('Visualizar - seleciona')
            //console.log(results.rows.item(0))

            var temp = [];
            for (let i = 0; i < results.rows.length; ++i) {
              temp.push(results.rows.item(i).Temperaturas.split(','));
            }
            //this.setState({ leituras: temp.map(silo => ({ ...silo, online: false })) })
            this.setState({
              pendulos: temp,
              idSiloUP: idSilo,
              dataHora: dataHora,
              equipamento: equipamento,
            });
            //this.setState({ temperaturas: temp.map(c => ( c.temperaturas )) })
            //console.log('Visualizar - Temperaturas do state')
            //console.log(this.state.temperaturas)
          }
        );
      });
      if (this.state.pendulos.length !== 0 && this.state.equipamento !== 0) {
        this.upload(
          this.state.idSiloUP,
          this.state.dataHora,
          this.state.equipamento
        );
      }
    } catch {
      console.log('erro db');
    }
  };

  render() {
    const {container, emailText, errorText} = styles;
    const {loading, email, error} = this.state;
    let equipamentosItems = this.state.cloudEquipamentos.map((s, i) => {
      return (
        <Picker.Item
          key={i}
          value={s.idEquipamento}
          label={s.nomeEquipamento + ' - ' + s.idEquipamento}
        />
      );
    });
    if (loading) {
      return (
        <View style={container}>
          <Loading />
        </View>
      );
    } else {
      return (
        <View style={container}>
          <View>
            <Modal
              animationType="slide"
              transparent={true}
              visible={this.state.modalVisible}
              onRequestClose={() => {
                Alert.alert('Modal fechado');
              }}>
              <View
                style={{
                  backgroundColor: 'rgba(0,0,0,0.7)',
                  width: '100%',
                  height: '100%',
                  alignContent:'center',
                  alignItems:'center',
                }}>
                <Picker
                  selectedValue={this.state.language}
                  itemStyle={{color:'#fff'}}
                  style={{width:200,height:200}}
                  onValueChange={(itemValue, itemIndex) => {
                    this.updateSilo(itemValue);
                  }}>
                  <Picker.Item label="Selecione um silo" value="0" />
                  {equipamentosItems}
                </Picker>
              </View>
            </Modal>
          </View>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <TouchableOpacity
              activeOpacity={0.7}
              style={
                this.state.tabLeitura ? styles.botoes : styles.botoesBorder
              }
              onPress={this.offlineRead}>
              <Text style={styles.textoBotoes}>Offline</Text>
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={0.7}
              style={
                this.state.tabLeitura ? styles.botoesBorder : styles.botoes
              }
              onPress={this.onlineRead}>
              <Text style={styles.textoBotoes}>Online</Text>
            </TouchableOpacity>
          </View>
          {this.state.tabLeitura ? (
            <ScrollView style={styles.scrollLeituras}>
              <FlatList
                data={this.state.cloud}
                renderItem={({item}) => (
                  <ItemListaLeitura
                    {...item}
                    onClick={this.abreLeitura}
                    onDelete={this.deletaLeitura}
                  />
                )}
                keyExtractor={item => item.idTermometria}
              />
            </ScrollView>
          ) : (
            <ScrollView style={styles.scrollLeituras}>
              <FlatList
                data={this.state.leituras}
                keyExtractor={item => `${item.IdLeitura}`}
                renderItem={({item}) => (
                  <ItemListaLeitura
                    {...item}
                    onClick={this.getTemperaturas}
                    onDelete={this.deletaLeitura}
                    loggedin={true}
                  />
                )}
              />
            </ScrollView>
          )}
          <View>
            {email ? (
              <Text style={emailText}>Your email: {email}</Text>
            ) : (
              <Text style={errorText}>{error}</Text>
            )}
          </View>
        </View>
      );
    }
  }

  onlineRead = () => {
    this.setState({tabLeitura: true});
  };

  offlineRead = () => {
    this.setState({tabLeitura: false});
  };
}

const styles = {
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  emailText: {
    alignSelf: 'center',
    color: 'black',
    fontSize: 10,
  },
  errorText: {
    alignSelf: 'center',
    fontSize: 18,
    color: 'red',
  },
  botoes: {
    width: '50%',
    backgroundColor: '#666',
    opacity: 0.9,
    alignItems: 'center',
    padding: 15,
    borderBottomColor: '#666',
    borderBottomWidth: 2,
  },
  botoesBorder: {
    width: '50%',
    backgroundColor: '#666',
    opacity: 0.9,
    alignItems: 'center',
    padding: 15,
    borderBottomColor: '#FE9A2E',
    borderBottomWidth: 2,
  },
  textoBotoes: {
    color: '#FE9A2E',
    fontSize: 16,
  },
};
