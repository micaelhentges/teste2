import React, {Component, Fragment} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {Input} from '../../components/Input';
import Loading from '../../components/Loading';
import axios from 'axios';
import deviceStorage from '../../services/deviceStorage';

export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      error: '',
      loading: false,
    };

    this.loginUser = this.loginUser.bind(this);
    this.onLoginFail = this.onLoginFail.bind(this);
  }

  loginUser() {
    const {email, password, password_confirmation} = this.state;

    this.setState({error: '', loading: true});

    // NOTE Post to HTTPS only in production
    axios
      .post('https://iot.kepler.com.br/api/login', {
        username: email,
        password: password,
      })
      .then(response => {
        deviceStorage.saveKey('id_token', response.data.token);
        deviceStorage.saveKey('id_usuario', response.data.usuario.id);
        deviceStorage.saveKey('id_empresa', response.data.usuario.idEmpresa);
        deviceStorage.saveKey('id_unidade', response.data.usuario.idUnidade);
        deviceStorage.saveKey('nivelAcesso', response.data.usuario.nivelAcesso);
        this.props.newJWT(response.data);
      })
      .catch(error => {
        console.log(error);
        this.onLoginFail();
      });
  }

  onLoginFail() {
    this.setState({
      error: 'Login Failed',
      loading: false,
    });
  }

  render() {
    const {email, password, error, loading} = this.state;
    const {form, section, errorTextStyle} = styles;

    return (
      <Fragment>
        <View style={form}>
          <View style={section}>
            <Input
              placeholder=""
              label="Usuário:"
              value={email}
              onChangeText={email => this.setState({email})}
            />
          </View>

          <View style={section}>
            <Input
              secureTextEntry
              placeholder=""
              label="Senha:"
              value={password}
              onChangeText={password => this.setState({password})}
            />
          </View>

          <Text style={errorTextStyle}>{error}</Text>

          {!loading ? (
            <TouchableOpacity style={styles.button} onPress={this.loginUser}>
              <Text style={styles.buttonLabel}>Entrar</Text>
            </TouchableOpacity>
          ) : (
            <Loading />
          )}
        </View>
      </Fragment>
    );
  }
}

const styles = {
  form: {
    width: '100%',
    borderTopWidth: 1,
    borderColor: '#ddd',
  },
  section: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    backgroundColor: '#fff',
    borderColor: '#ddd',
  },
  errorTextStyle: {
    alignSelf: 'center',
    fontSize: 18,
    color: 'red',
  },
  button: {
    width: '100%',
    backgroundColor: '#777',
    borderRadius: 7,
    alignItems: 'center',
    marginTop: 15,
    padding: 15,
  },
  buttonLabel: {
    color: '#FE9A2E',
    fontSize: 16,
  },
};
