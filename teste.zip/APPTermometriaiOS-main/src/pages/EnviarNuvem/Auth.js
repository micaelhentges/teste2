import React, {Component} from 'react';
import {View, Image} from 'react-native';
import Login from './Login';

import kwcloud from '../../../assets/kwcloud.png';

export default class Auth extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showLogin: false,
    };
    this.whichForm = this.whichForm.bind(this);
    this.authSwitch = this.authSwitch.bind(this);
  }

  authSwitch() {
    this.setState({
      showLogin: !this.state.showLogin,
    });
  }

  whichForm() {
    return <Login newJWT={this.props.newJWT} authSwitch={this.authSwitch} />;
  }

  render() {
    return (
      <>
        <View style={styles.container}>
          <Image style={styles.imgLogo} source={kwcloud} resizeMode="contain" />
          {this.whichForm()}
        </View>
      </>
    );
  }
}

const styles = {
  container: {
    paddingLeft: 15,
    paddingRight: 15,
    flexDirection: 'column',
    alignItems: 'center',
  },
  imgLogo: {
    width: '80%',
  },
};
