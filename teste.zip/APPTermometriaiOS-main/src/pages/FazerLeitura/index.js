import React, {Component} from 'react';

import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  FlatList,
  NativeEventEmitter,
  PermissionsAndroid,
  Platform,
  NativeModules,
  ScrollView,
  Alert,
} from 'react-native';

import BleManager from 'react-native-ble-manager';
import {Buffer} from 'buffer';

import {openDatabase} from 'react-native-sqlite-storage';
import moment from 'moment';

const BleManagerModule = NativeModules.BleManager;
const bleManagerEmitter = new NativeEventEmitter(BleManagerModule);
import TabelaSilo from '../../components/TabelaSilo';
import Loading from '../../components/Loading';

export default class FazerLeitura extends Component {
  constructor(props) {
    super(props);
    this.state = {
      scanning: false,
      isConnected: false,
      text: '',
      receiveData: '',
      data: [],
      isMonitoring: false,
      processing: false,
      silos: [],
      temps: [],
      idSiloTemps: 0,
      showTemps: false,
      statusConectado: false,
      idConectado: '',
      nomeConectado: 'Selecione um Silo',
      peripherals: new Map(),
      appState: '',
    };
    this.dbMsg = '';
    this.db = openDatabase({name: 'baseDados.db'}, this.dbOpen, this.dbError);
    this.getDadosBD();
    this.bluetoothReceiveData = []; //Cache de dados recebidos por Bluetooth
    this.deviceMap = new Map();

    this.handleDiscoverPeripheral = this.handleDiscoverPeripheral.bind(this);
    this.handleStopScan = this.handleStopScan.bind(this);
    this.handleUpdateValueForCharacteristic = this.handleUpdateValueForCharacteristic.bind(
      this
    );
    this.handleDisconnectedPeripheral = this.handleDisconnectedPeripheral.bind(
      this
    );

    this.penduloAux = '';
    this.penduloFirstId = '';
    this.penduloId = '';
    this.pendulos = [];
  }

  dbOpen = () => {
    if (this.dbMsg) {
      Alert.alert('Sucesso', this.dbMsg);
    }
  };

  dbError = err => {
    console.log('db error', err);
  };

  retrieveConnected() {
    BleManager.getConnectedPeripherals([]).then(results => {
      if (results.length == 0) {
        console.log('No connected peripherals');
      }
      console.log('connected peripherals', results);
      var peripherals = this.state.peripherals;
      for (var i = 0; i < results.length; i++) {
        var peripheral = results[i];
        peripheral.connected = true;
        peripherals.set(peripheral.id, peripheral);
        this.setState({peripherals});
      }
    });
  }

  handleDiscoverPeripheral(peripheral) {
    var peripherals = this.state.peripherals;
    console.log('Got ble peripheral', peripheral);
    if (!peripheral.name) {
      peripheral.name = 'NO NAME';
    }
    let i;
    for (i = 0; i < this.state.silos.length; i++) {
      if (this.state.silos[i].macDevice == peripheral.id) {
        peripheral.nomeExib = this.state.silos[i].nomeExib;
        peripheral.sqlId = this.state.silos[i].IdSilo;
        peripherals.set(peripheral.id, peripheral);
        this.setState({peripherals});
      }
    }
  }

  handleDisconnectedPeripheral(data) {
    let peripherals = this.state.peripherals;
    let peripheral = peripherals.get(data.peripheral);
    if (peripheral) {
      peripheral.connected = false;
      peripherals.set(peripheral.id, peripheral);
      this.setState({peripherals});
    }
    this.setState({isMonitoring: false});
    console.log('Disconnected from ' + data.peripheral);
  }

  handleUpdateValueForCharacteristic(data) {
    console.log('handleUpdateValueForCharacteristic()');

    this.setState({isMonitoring: true});

    if (data.value !== null) {
      let valueTmp = new Buffer(data.value, 'base64').toString();
      this.bluetoothReceiveData.push(valueTmp); //Se a quantidade de dados for grande, eles serão recebidos várias vezes.
      this.setState({receiveData: this.bluetoothReceiveData.join('')});

      let pendulo = valueTmp;
      this.penduloAux += pendulo;
      let checkFirstPend = this.penduloAux.split(' ');

      console.log(checkFirstPend);

      //chegou no ultimo pendulo
      if (this.penduloFirstId === checkFirstPend[0]) {
        this.pendulos = this.pendulos.sort((a, b) => a[0] - b[0]);
        this.setState({showTemps: true, temps: this.pendulos});
        this.penduloFirstId = '';
        this.pendulos = [];
        BleManager.stopNotification(data.peripheral, 'FFE0', 'FFE1').catch(
          error => console.log('stopNotification', error)
        );
        BleManager.disconnect(data.peripheral);
      }

      // this.penduloAux com todos os sensores do pendulo
      if (this.penduloAux.includes(';')) {
        this.penduloAux = this.penduloAux.replace(';', '');
        this.penduloAux = this.penduloAux.replace('\r', '');
        let penduloArray = this.penduloAux.split(' ');

        if (
          !penduloArray[0].includes('undefined') &&
          penduloArray[0] != 'undefined' &&
          penduloArray[1] > 0
        ) {
          if (!this.penduloFirstId) {
            this.penduloFirstId = penduloArray[0];
          }
          this.pendulos = [...this.pendulos, penduloArray];
        }
        this.penduloAux = '';
        penduloArray = [];
      }
    }
  }

  handleStopScan() {
    console.log('handleStopScan()');
    this.setState({scanning: false});
  }

  startScan() {
    console.log('startScan()');
    this.setState({scanning: true});
    BleManager.enableBluetooth().catch(() => {
      Alert(
        'Alerta',
        'Você precisa ativar o bluetooth do telefone para conectar!'
      );
      this.setState({scanning: false});
    });
    if (!this.state.scanning) {
      BleManager.scan([], 3, true).then(() => {
        console.log('Scanning...');
      });
    }
  }

  componentDidMount() {
    BleManager.start({showAlert: true});

    this.handlerDiscover = bleManagerEmitter.addListener(
      'BleManagerDiscoverPeripheral',
      this.handleDiscoverPeripheral
    );
    this.handlerStop = bleManagerEmitter.addListener(
      'BleManagerStopScan',
      this.handleStopScan
    );
    this.handlerDisconnect = bleManagerEmitter.addListener(
      'BleManagerDisconnectPeripheral',
      this.handleDisconnectedPeripheral
    );
    this.handlerUpdate = bleManagerEmitter.addListener(
      'BleManagerDidUpdateValueForCharacteristic',
      this.handleUpdateValueForCharacteristic
    );

    if (Platform.OS === 'android' && Platform.Version >= 23) {
      PermissionsAndroid.check(
        //PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION
        //ALTERAÇÃO IGOR
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION,
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
        PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT

      ).then(result => {
        if (result) {
          console.log('Permission is OK');
        } else {
          PermissionsAndroid.requestPermission(
            //PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION
            //ALTERAÇÃO IGOR
            PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
            PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION,
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN,
            PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT
          ).then(result => {
            if (result) {
              console.log('User accept');
            } else {
              console.log('User refuse');
            }
          });
        }
      });
    }

    this.retrieveConnected();
  }

  componentWillUnmount() {
    this.handlerDiscover.remove();
    this.handlerStop.remove();
    this.handlerDisconnect.remove();
    this.handlerUpdate.remove();
  }

  async retriveServices(peripheral) {
    await BleManager.retrieveServices(peripheral.id).then(peripheralInfo => {
      console.log('Peripheral info:', peripheralInfo);
      setTimeout(() => {
        BleManager.startNotification(peripheral.id, 'FFE0', 'FFE1').catch(
          error => console.log('startNotification', error)
        );
      }, 1600);
    });
  }

  async connect(peripheral) {
    console.log('connect()');
    if (peripheral) {
      if (peripheral.connected) {
        BleManager.disconnect(peripheral.id);
      } else {
        await BleManager.connect(peripheral.id)
          .then(() => {
            let peripherals = this.state.peripherals;
            let p = peripherals.get(peripheral.id);
            if (p) {
              p.connected = true;
              peripherals.set(peripheral.id, p);
              console.log('peripheral connected', peripheral);
              this.setState({
                peripherals,
                isConnected: true,
                idSiloTemps: peripheral.sqlId,
              });
            }
            this.retriveServices(peripheral);
          })
          .catch(error => console.log('connect', error));
      }
    }
  }

  listDados = () => {
    if (this.state.showTemps) {
      return (
        <View style={{flex: 1}}>
          <TabelaSilo temps={this.state.temps} />
          <View style={styles.linhaBotoes}>
            <TouchableOpacity
              style={styles.button}
              onPress={() =>
                this.setState({
                  showTemps: false,
                  nomeConectado: 'Selecione um Silo',
                  idConectado: '',
                  idSiloTemps: 0,
                })
              }>
              <Text style={styles.buttonLabel}>Cancelar</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.button}
              onPress={() => this.gravaDados()}>
              <Text style={styles.buttonLabel}>Gravar</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    } else {
      const list = Array.from(this.state.peripherals.values());
      return (
        <ScrollView>
          <FlatList
            renderItem={this.renderItem}
            keyExtractor={item => item.id}
            data={list}
            ListHeaderComponent={this.renderHeader}
            extraData={[
              this.state.isConnected,
              this.state.text,
              this.state.receiveData,
              this.state.isMonitoring,
              this.state.scanning,
            ]}
            keyboardShouldPersistTaps="handled"
            style={{paddingTop: 0, paddingLeft: 10, paddingRight: 10}}
          />
        </ScrollView>
      );
    }
  };

  gravaDados = () => {
    console.log('gravaDados()');
    const dataLeit = moment(new Date()).format('YYYY-MM-DD HH:mm:ss');
    let idLeitura = 0;
    this.db.transaction(tx => {
      tx.executeSql(
        'INSERT INTO Leituras (Data, IdSilo) VALUES (?, ?)',
        [dataLeit, this.state.idSiloTemps],
        (txn, results) => {
          if (results.rowsAffected > 0) {
            idLeitura = results.insertId;
            // Fazer um looping de todos os cabos
            for (let i = 0; i <= this.state.temps.length; i++) {
              if (this.state.temps[i]) {
                let t = this.state.temps[i].join();
                tx.executeSql(
                  'INSERT INTO Temperaturas (IdLeitura, NumCabo, Temperaturas) VALUES (?, ?, ?)',
                  [idLeitura, i, t],
                  function(txn, resultsTemps) {
                    console.log(resultsTemps);
                  }
                );
              }
            }
            this.setState({
              showTemps: false,
              nomeConectado: 'Selecione um Silo',
              idConectado: '',
              idSiloTemps: 0,
            });
            Alert.alert('Sucesso', 'Dados gravados corretamente');
          } else {
            Alert.alert('Erro', 'Falha ao gravar dados');
          }
        }
      );
      //console.log('idLeitura: ' + idLeitura)
    });
  };

  getDadosBD = () => {
    console.log('getDadosBD()');
    this.db.transaction(tx => {
      tx.executeSql(
        'SELECT * FROM Silos order by ordemExib',
        [],
        (tx, results) => {
          var temp = [];
          for (let i = 0; i < results.rows.length; ++i) {
            temp.push(results.rows.item(i));
          }
          //console.log('FazerLeitura - set state')
          this.setState({
            silos: temp.map(silo => ({...silo, conectado: 0, status: ''})),
            // 0 - Desconectado, 1 - Conectando, 2 - Conectado, 3 - Falha
          });
        }
      );
    });
  };

  renderHeader = () => {
    return (
      <View style={{marginTop: 15}}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
          <TouchableOpacity
            activeOpacity={0.7}
            style={[
              styles.buttonView,
              {height: 40, width: '100%', alignItems: 'center'},
            ]}
            onPress={() => this.startScan()}>
            <Text style={styles.buttonText}>
              {this.state.scanning ? 'Pesquisando' : 'Pesquisa por Bluetooth'}
            </Text>
          </TouchableOpacity>
        </View>

        {this.state.peripherals.size > 0 && (
          <Text
            style={{
              marginBottom: 15,
              marginTop: 10,
              textAlign: 'center',
              fontWeight: '700',
            }}>
            Equipamentos disponíveis
          </Text>
        )}
      </View>
    );
  };

  renderItem = item => {
    let data = item.item;
    return (
      <TouchableOpacity
        activeOpacity={0.7}
        disabled={this.state.isConnected ? true : false}
        onPress={() => {
          this.connect(data);
        }}
        style={styles.item}>
        <View style={{flexDirection: 'row'}}>
          <Text style={{color: 'black'}}>
            {data.nomeExib ? data.nomeExib : data.name}
          </Text>
          <Text style={{color: 'red', marginLeft: 50}}>
            {data.connected ? 'Em conexão...' : ''}
          </Text>
        </View>
        <Text>{data.id}</Text>
      </TouchableOpacity>
    );
  };

  render() {
    return (
      <View style={styles.container}>
        {this.state.scanning && <Loading text="Buscando equipamentos" />}
        {this.state.isMonitoring && <Loading text="Fazendo Leitura" />}
        <View style={styles.devices}>{this.listDados()}</View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  //Silo Selecionado ou Selecione Silo
  titulo: {
    backgroundColor: '#EEE',
    alignItems: 'center',
    width: '100%',
  },
  textoTitulo: {
    fontSize: 16,
    padding: 10,
  },
  //Silo Selecionado ou Selecione Silo FIM

  devices: {
    // Container que lista todos os dispositivos
    flex: 1,
    width: '100%',
  },
  deviceName: {
    fontSize: 15,
    color: 'grey',
  },
  deviceStatus: {
    fontSize: 12,
    color: 'grey',
  },
  deviceViewName: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    width: '40%',
  },
  deviceNameWrap: {
    flexDirection: 'row',
    padding: '20 0',
    marginTop: 10,
    backgroundColor: '#DDD',
    borderRadius: 10,
  },
  statusContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: '10%',
  },
  linhaBotoes: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#EEE',
  },
  item: {
    flexDirection: 'column',
    borderColor: 'rgb(235,235,235)',
    borderStyle: 'solid',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  buttonView: {
    height: 30,
    backgroundColor: 'rgb(33, 150, 243)',
    borderRadius: 5,
    justifyContent: 'center',
    alignItems: 'center',
    //alignItems: 'flex-start',
    marginTop: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 12,
  },
  button: {
    backgroundColor: '#666',
    width: 90,
    height: 40,
    margin: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
  },
  buttonLabel: {
    fontSize: 16,
    color: '#FE9A2E',
    //fontWeight: 'bold',
  },
});
