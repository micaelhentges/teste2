import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';
const Stack = createStackNavigator();
import Home from './pages/Home';
import Configuracoes from './pages/Configuracoes';
import Silos from './pages/Configuracoes/Silos';
import SilosAdd from './pages/Configuracoes/SilosAdd';
import SilosConf from './pages/Configuracoes/SilosConf';
import FazerLeitura from './pages/FazerLeitura';
import ConsultarLeituras from './pages/ConsultarLeituras';
import EnviarNuvem from './pages/EnviarNuvem';
import VisualizarLeitura from './pages/VisualizarLeitura';

export default function Routes() {
  const back = ' ';

  return (
    <Stack.Navigator
      headerBackTitleVisible={false}
      headerLayoutPreset="center"
      screenOptions={{
        headerStyle: {
          backgroundColor: '#ff7500',
        },
        headerTintColor: '#FFF',
      }}>
      <Stack.Screen
        name="Home"
        component={Home}
        options={{title: 'Início', headerShown: false}}
      />
      <Stack.Screen
        name="FazerLeitura"
        component={FazerLeitura}
        options={{title: 'Fazer Leitura', headerBackTitle: back}}
      />
      <Stack.Screen
        name="ConsultarLeituras"
        component={ConsultarLeituras}
        options={{title: 'Consultar Leituras', headerBackTitle: back}}
      />
      <Stack.Screen
        name="Configuracoes"
        component={Configuracoes}
        options={{title: 'Configurações'}}
      />
      <Stack.Screen
        name="Silos"
        component={Silos}
        options={{title: 'Silos', headerBackTitle: back}}
      />
      <Stack.Screen
        name="SilosAdd"
        component={SilosAdd}
        options={{title: 'Adicionar Silo', headerBackTitle: back}}
      />
      <Stack.Screen
        name="SilosConf"
        component={SilosConf}
        options={{title: 'Configurar Silo', headerBackTitle: back}}
      />
      <Stack.Screen
        name="EnviarNuvem"
        component={EnviarNuvem}
        options={{title: 'Enviar para Nuvem', headerBackTitle: back}}
      />
      <Stack.Screen
        name="VisualizarLeitura"
        component={VisualizarLeitura}
        options={{title: 'Visualizar Leitura', headerBackTitle: back}}
      />
    </Stack.Navigator>
  );
}
