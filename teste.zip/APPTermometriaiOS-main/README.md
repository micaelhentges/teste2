#react-native-navigation install
https://storage.googleapis.com/golden-wind/bootcamp-gostack/Atualiza%C3%A7%C3%A3o/upgrade-react-navigation.pdf

#Google Play Console / OneSignal Push Notifications / 
synk.kw@gmail.com
PceKw@20!8

##Appcenter
abrir com conta do gmail synk.kw@gmail.com

##ANDROID
App Name: ´Termometria KW´
App Package: ´com.apptermometria´
CodePush keys: ´appcenter codepush deployment list -a synk.kw-gmail.com/Termometria-Digital-Portatil-android -k´
Codepush to Production: ´appcenter codepush release-react -a synk.kw-gmail.com/Termometria-Digital-Portatil-android -d Production´
Codepush to Staging: ´appcenter codepush release-react -a synk.kw-gmail.com/Termometria-Digital-Portatil-android -d Staging´


##IOS: 
App Name: ´Termometria Digital Portátil Kepler Weber´
App package: ´com.tdportatilble´
CodePush keys: ´appcenter codepush deployment list -a synk.kw-gmail.com/Termometria-Digital-Portatil-ios -k´
package ´com.tdportatilble´# APPTermometria
